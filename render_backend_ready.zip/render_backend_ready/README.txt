Render backend ready package

Upload these files to a GitHub repo and connect the repo to Render.

Files:
- backend_fastapi.py
- requirements.txt
- render.yaml

After Render deploys, copy your public URL:
https://your-service.onrender.com

Then put that URL into your builder as:
Public backend API URL

Your generated HTML pages must contain:
const apiBase = 'https://your-service.onrender.com'
